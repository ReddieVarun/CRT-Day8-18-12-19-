 #include <stdio.h>
 int main()
 {
 		int p,a,b;
 	/*p=printf("gitam");
 		 
 		printf("%d",p);*/
 		p=scanf("%d%d",&a,&b); 
 		printf("%d",p);
 		return 0;
  } 